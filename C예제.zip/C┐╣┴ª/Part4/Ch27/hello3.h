#include <stdio.h>

void hello()
{
    printf("hello3.h : Everybody!, Hello?\n");
}