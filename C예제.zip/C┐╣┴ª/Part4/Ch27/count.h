//#ifndef _COUNT_H_
//#define _COUNT_H_ 20

int count=0;

//#endif