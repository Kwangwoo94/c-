#include <stdio.h>

void hello()
{
    printf("hello1.h : Hello Everybody!\n");
}