#include "count.h"

int minus(int a,int b)
{
    count++;
    return a-b;
}