#include "count.h"

int add(int a,int b)
{
    count++;
    return a+b;
}