extern int cal_num;

double add(double a,double b);
double minus(double a,double b);
double multiple(double a,double b);
double divide(double a,double b);