#include <stdio.h>

int main()
{
    printf("ABCDEFG \n");
    printf("1234567 ");

    return 0;
}