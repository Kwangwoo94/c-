#include <stdio.h>

int main()
{
    char *str="AAA" "BBB"; //char *str ="AAABBB"

    puts(str);
    puts("EEE" "FFF");

    return 0;
}