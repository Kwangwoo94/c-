#include <stdio.h>

int main(void)
{
    printf("My age : %d\n", 29);
    printf("%d is my point\n", 100);
    printf("Good \nmorning \neverybody\n");

    return 0;
}