#include <stdio.h>

int main(void)
{
    printf("Hello Everybody\n");
    printf("$d\n",1234);
    printf("$d $d\n", 10, 20);
    return 0;
}