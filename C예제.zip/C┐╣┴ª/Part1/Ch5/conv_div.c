#include <stdio.h>

int main(void)
{
    int a=1;
    int b=2;

    float f = (float)a/b;
    printf("나눗셈 결과 : %f\n", f);

    return 0;
}