#include <stdio.h>

int main(void)
{
    char ch1='A';
    char ch2=65;

    printf("%d %d\n",ch1,ch2);
    printf("%c %c\n",ch1,ch2);

    return 0;
}