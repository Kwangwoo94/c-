#include <stdio.h>

int main(void)
{
    int result;
    result = 3+4;

    printf("덧셈 결과 : %d\n", result);
    printf("%d 더하기 %d는 %d입니다",3,4, result);
    printf("변수 result에 저장된 값: %d\n", result);
}