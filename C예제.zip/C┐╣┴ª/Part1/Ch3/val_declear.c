#include <stdio.h>

int main(void)
{
    int a,b;
    int c=30, d=40;

    a=10;
    b=20;

    printf("%d %d \n",a,b);
    printf("%d %d \n",c,d);

    return 0;
}