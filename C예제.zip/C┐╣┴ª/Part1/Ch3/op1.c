#include <stdio.h>

int main(void)
{
    int val1=4;
    int val2=2;

    printf("두수의 덧셈: %d\n", val1+val2);
    printf("두수의 뺄셈: %d\n", val1-val2);
    printf("두수의 곱셈: %d\n", val1*val2);
    printf("두수의 나눗셈: %d\n", val1/val2);
    printf("두수의 나머지: %d\n", val1%val2);

    return 0;
}