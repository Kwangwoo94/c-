#include <stdio.h>

int main(void)
{
    printf("Hello Everybory! \n");
    printf("I love puppy! \n");
    printf("Today is Friday \n");

    return 0;
}