#include <stdio.h>

int main(void)
{
    int i=0;

    while (i<10)
    {
        printf("Hello World!\n");
        i++;
    }

    return 0;
    
}