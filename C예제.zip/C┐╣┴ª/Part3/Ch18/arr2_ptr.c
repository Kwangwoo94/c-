#include <stdio.h>

int main(void)
{
    int arr1[3][2];
    int arr2[2][3];

    printf("arr1 : %d\n",arr1);
    printf("arr1+1 : %d\n",arr1+1);
    printf("arr1+2 : %d\n",arr1+2);

    printf("arr2 : %d\n",arr2);
    printf("arr2+1 : %d\n",arr2+1);
    printf("arr2+2 : %d\n",arr2+2);

    return 0;
}