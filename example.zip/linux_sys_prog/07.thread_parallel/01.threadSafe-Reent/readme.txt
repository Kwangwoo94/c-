https://deadbeef.me/2017/09/reentrant-threadsafe 참조
https://blog.the-pans.com/reentrant/