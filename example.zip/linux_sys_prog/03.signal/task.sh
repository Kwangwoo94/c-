echo "I am child with pid of $$"
echo "I am exiting with 100"
exit 100